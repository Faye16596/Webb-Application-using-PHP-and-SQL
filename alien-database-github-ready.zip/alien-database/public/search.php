<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
$alien=null;$error=null;$id='';
if($_SERVER['REQUEST_METHOD']==='POST'){$id=trim($_POST['id']??'');if($id===''||filter_var($id,FILTER_VALIDATE_INT)===false)$error='Please enter a valid numeric ID.';else{$stmt=$pdo->prepare('SELECT ID,FARLIGHET,RAS FROM ALIEN WHERE ID=:id');$stmt->execute(['id'=>(int)$id]);$alien=$stmt->fetch();if(!$alien)$error='No alien was found with that ID.';}}
function e(string|int|null $value):string{return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');}require __DIR__.'/partials/header.php';
?><h1>Search Aliens</h1><div class="card form-card"><form method="post"><label for="id">Alien ID</label><input id="id" name="id" type="number" value="<?=e($id)?>" required><button class="button">Search</button></form></div><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?><?php if($alien):?><div class="card table-wrapper"><table><thead><tr><th>ID</th><th>Farlighet</th><th>Ras</th></tr></thead><tbody><tr><td><?=e($alien['ID'])?></td><td><?=e($alien['FARLIGHET'])?></td><td><?=e($alien['RAS'])?></td></tr></tbody></table></div><?php endif;?><?php require __DIR__.'/partials/footer.php'; ?>
