<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
$result=null;$error=null;$id='';
if($_SERVER['REQUEST_METHOD']==='POST'){$id=trim($_POST['id']??'');if($id===''||filter_var($id,FILTER_VALIDATE_INT)===false)$error='Please enter a valid ship ID.';else{try{$stmt=$pdo->prepare('CALL GET_SHIP_SIZE(:id)');$stmt->execute(['id'=>(int)$id]);$result=$stmt->fetch();$stmt->closeCursor();if(!$result)$error='The procedure returned no result.';}catch(PDOException $e){$error='The stored procedure could not be executed.';}}}
function e(string|int|null $value):string{return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');}require __DIR__.'/partials/header.php';
?><h1>Ship Capacity</h1><div class="card form-card"><form method="post"><label for="id">Ship ID</label><input id="id" name="id" type="number" value="<?=e($id)?>" required><button class="button">Execute Procedure</button></form></div><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?><?php if($result):?><div class="card"><h2>Result</h2><p>Seats: <strong><?=e($result['SITTPLATSER']??'')?></strong></p></div><?php endif;?><?php require __DIR__.'/partials/footer.php'; ?>
