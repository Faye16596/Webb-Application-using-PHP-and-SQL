<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: index.php');exit;}$id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);if($id===false||$id===null){header('Location: index.php?message='.urlencode('Invalid alien ID.'));exit;}$stmt=$pdo->prepare('DELETE FROM ALIEN WHERE ID=:id');$stmt->execute(['id'=>$id]);$message=$stmt->rowCount()>0?'Alien deleted successfully.':'No alien was found with that ID.';header('Location: index.php?message='.urlencode($message));exit;
