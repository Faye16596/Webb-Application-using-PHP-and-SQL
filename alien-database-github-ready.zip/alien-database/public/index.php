<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';

$aliens = $pdo->query('SELECT ID, FARLIGHET, RAS FROM ALIEN ORDER BY ID')->fetchAll();
function e(string|int|null $value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
require __DIR__ . '/partials/header.php';
?>
<div class="page-heading"><div><h1>Alien Records</h1><p>Manage records stored in MySQL.</p></div><a class="button" href="create.php">Add Alien</a></div>
<?php if (isset($_GET['message'])): ?><div class="alert success"><?= e($_GET['message']) ?></div><?php endif; ?>
<div class="card table-wrapper">
<?php if (!$aliens): ?><p>No alien records were found.</p><?php else: ?>
<table><thead><tr><th>ID</th><th>Farlighet</th><th>Ras</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($aliens as $alien): ?><tr><td><?= e($alien['ID']) ?></td><td><?= e($alien['FARLIGHET']) ?></td><td><?= e($alien['RAS']) ?></td><td class="actions"><a href="edit.php?id=<?= urlencode((string)$alien['ID']) ?>">Edit</a><form action="delete.php" method="post" onsubmit="return confirm('Delete this alien?');"><input type="hidden" name="id" value="<?= e($alien['ID']) ?>"><button class="link-button danger" type="submit">Delete</button></form></td></tr><?php endforeach; ?>
</tbody></table>
<?php endif; ?></div>
<?php require __DIR__ . '/partials/footer.php'; ?>
