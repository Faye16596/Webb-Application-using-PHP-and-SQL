<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
$errors=[]; $id=''; $farlighet=''; $ras='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id=trim($_POST['id']??''); $farlighet=trim($_POST['farlighet']??''); $ras=trim($_POST['ras']??'');
    if ($id==='' || filter_var($id,FILTER_VALIDATE_INT)===false) $errors[]='ID must be a valid number.';
    if ($farlighet==='') $errors[]='Farlighet is required.';
    if ($ras==='') $errors[]='Ras is required.';
    if (!$errors) { try { $stmt=$pdo->prepare('INSERT INTO ALIEN (ID,FARLIGHET,RAS) VALUES (:id,:farlighet,:ras)'); $stmt->execute(['id'=>(int)$id,'farlighet'=>$farlighet,'ras'=>$ras]); header('Location: index.php?message='.urlencode('Alien created successfully.')); exit; } catch(PDOException $e){ $errors[]='The alien could not be created. The ID may already exist.'; } }
}
function e(string|int|null $value): string { return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8'); }
require __DIR__ . '/partials/header.php';
?><h1>Add Alien</h1><?php require __DIR__.'/partials/errors.php'; ?><div class="card form-card"><form method="post"><label for="id">ID</label><input id="id" name="id" type="number" value="<?=e($id)?>" required><label for="farlighet">Farlighet</label><input id="farlighet" name="farlighet" value="<?=e($farlighet)?>" required><label for="ras">Ras</label><input id="ras" name="ras" value="<?=e($ras)?>" required><div class="form-actions"><button class="button">Create Alien</button><a class="button secondary" href="index.php">Cancel</a></div></form></div><?php require __DIR__.'/partials/footer.php'; ?>
