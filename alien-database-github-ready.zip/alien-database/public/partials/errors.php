<?php if(!empty($errors)): ?><div class="alert error"><ul><?php foreach($errors as $error): ?><li><?=e($error)?></li><?php endforeach; ?></ul></div><?php endif; ?>
