</main><footer class="site-footer"><div class="container"><p>PHP &amp; MySQL database project</p></div></footer></body></html>
