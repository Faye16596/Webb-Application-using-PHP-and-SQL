# Alien Database

A small PHP and MySQL web application originally created as a learning project and later refactored for cleaner structure, safer database access, validation, and a consistent interface.

## Features

- Create alien records
- View all alien records
- Search for an alien by ID
- Update alien records
- Delete alien records
- Execute a MySQL stored procedure for ship capacity
- PDO database access
- Prepared SQL statements
- Basic server-side validation
- Escaped HTML output

## Technologies

PHP · MySQL · PDO · HTML · CSS

## Setup

1. Create the MySQL database/tables used by the application.
2. Copy `.env.example` to `.env` and enter your local credentials.
3. From the project directory run:

```bash
php -S localhost:8000 -t public
```

4. Open `http://localhost:8000`.

The original database uses the `WIDE` database and `ALIEN` / `SKEPP` tables. The Ship Capacity page expects a stored procedure named `GET_SHIP_SIZE` that accepts a ship ID and returns `SITTPLATSER`.
